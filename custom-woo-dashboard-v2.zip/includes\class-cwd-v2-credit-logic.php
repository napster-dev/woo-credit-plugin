<?php

/**
 * Credit Logic class
 */

if (! defined('ABSPATH')) {
	exit;
}

class CWD_V2_Credit_Logic
{

	public static function init()
	{
		// Handle pay balance submission
		add_action('template_redirect', array(__CLASS__, 'handle_pay_balance'));

		// Handle credit limit increase request
		add_action('template_redirect', array(__CLASS__, 'handle_credit_increase_request'));

		// Handle new trade account application submission
		add_action('template_redirect', array(__CLASS__, 'handle_trade_application_submission'));

		// Set price of credit payment product in cart
		add_action('woocommerce_before_calculate_totals', array(__CLASS__, 'set_credit_payment_price'), 10, 1);
		add_filter( 'woocommerce_available_payment_gateways', array( __CLASS__, 'filter_account_payment_gateways' ), 9999 );

		// Hook into order payment to decrease balance
		add_action('woocommerce_payment_complete', array(__CLASS__, 'reduce_credit_balance_on_payment'));
		add_action('woocommerce_order_status_processing', array(__CLASS__, 'reduce_credit_balance_on_payment'));
		add_action('woocommerce_order_status_completed', array(__CLASS__, 'reduce_credit_balance_on_payment'));
		add_action('woocommerce_checkout_create_order_line_item', array(__CLASS__, 'add_payment_item_metadata'), 10, 4);

		// Hook into order checkout and status changes to immediately deduct available credit and charge account
		add_action('woocommerce_checkout_order_processed', array(__CLASS__, 'apply_credit_order_charge'), 10, 1);
		add_action('woocommerce_payment_complete', array(__CLASS__, 'apply_credit_order_charge'), 10, 1);
		add_action('woocommerce_order_status_processing', array(__CLASS__, 'apply_credit_order_charge'), 10, 1);
		add_action('woocommerce_order_status_completed', array(__CLASS__, 'apply_credit_order_charge'), 10, 1);
		add_action('woocommerce_order_status_on-hold', array(__CLASS__, 'apply_credit_order_charge'), 10, 1);
		add_action('woocommerce_order_status_cancelled', array(__CLASS__, 'reverse_credit_order_charge'), 10, 1);
		add_action('woocommerce_order_status_failed', array(__CLASS__, 'reverse_credit_order_charge'), 10, 1);

		// Optional payoff of outstanding credit balance at checkout
		add_action('woocommerce_review_order_before_payment', array(__CLASS__, 'render_checkout_credit_payoff_option'));
		add_action('woocommerce_checkout_update_order_review', array(__CLASS__, 'handle_checkout_update_payoff_preference'));
		add_action('woocommerce_cart_calculate_fees', array(__CLASS__, 'apply_checkout_credit_payoff_fee'));
		add_action('woocommerce_checkout_create_order', array(__CLASS__, 'save_checkout_credit_payoff_meta'), 10, 2);

		// Hook into refunds on credit-paid orders to decrease the outstanding balance.
		add_action('woocommerce_order_refunded', array(__CLASS__, 'handle_credit_order_refund'), 10, 2);
	}

	public static function get_credit_payment_product_id()
	{
		$product_id = (int) get_option('cwd_v2_credit_payment_product_id');
		if ($product_id && get_post_status($product_id) === 'publish') {
			return $product_id;
		}

		if (class_exists('CWD_V2_Activator')) {
			CWD_V2_Activator::activate();
			$product_id = (int) get_option('cwd_v2_credit_payment_product_id');
			if ($product_id && get_post_status($product_id) === 'publish') {
				return $product_id;
			}
		}

		$new_product_id = wp_insert_post(array(
			'post_title'   => 'Credit Account Payment',
			'post_content' => 'Used for paying off credit balances.',
			'post_status'  => 'publish',
			'post_type'    => 'product',
		));
		if (! is_wp_error($new_product_id)) {
			update_post_meta($new_product_id, '_virtual', 'yes');
			update_post_meta($new_product_id, '_sold_individually', 'yes');
			update_post_meta($new_product_id, '_price', '0');
			update_post_meta($new_product_id, '_regular_price', '0');
			update_option('cwd_v2_credit_payment_product_id', $new_product_id);
			return $new_product_id;
		}

		return 0;
	}

	public static function filter_account_payment_gateways( $gateways ) {
		if ( ! is_array( $gateways ) ) {
			return $gateways;
		}

		// Completely remove Direct Bank Transfer (BACS) across checkout
		unset( $gateways['bacs'] );

		// Strictly remove all duplicate third-party credit gateways across checkout
		// so that only the official "Pay on Credit Account" gateway (cwd_v2_credit_account) remains available.
		$duplicate_credit_gateways = array(
			'credits',
			'wc_cs',
			'wc_cs_credits',
			'fpc_credits',
			'wc_credit_gateway',
			'credits_gateway',
			'woocommerce_credits',
			'trade_credit',
		);
		foreach ( $duplicate_credit_gateways as $dup_id ) {
			if ( isset( $gateways[ $dup_id ] ) ) {
				unset( $gateways[ $dup_id ] );
			}
		}

		$product_id = (int) self::get_credit_payment_product_id();
		$is_account_payment = false;
		if ( isset( WC()->cart ) && WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $cart_item ) {
				if ( $product_id && (int) ( $cart_item['product_id'] ?? 0 ) === $product_id ) {
					$is_account_payment = true;
					break;
				}
			}
		}

		// Check order-pay page
		if ( ! $is_account_payment && isset( $_GET['pay_for_order'] ) ) {
			$order_id = absint( get_query_var( 'order-pay' ) );
			$order = wc_get_order( $order_id );
			if ( $order ) {
				foreach ( $order->get_items() as $item ) {
					if ( $product_id && (int) $item->get_product_id() === $product_id ) {
						$is_account_payment = true;
						break;
					}
				}
			}
		}

		if ( $is_account_payment || ( isset( WC()->session ) && WC()->session->get( 'cwd_payoff_credit_balance', false ) ) ) {
			// Customers cannot pay their credit account using credit account itself
			unset( $gateways['cwd_v2_credit_account'] );
		}

		return $gateways;
	}

	public static function handle_pay_balance()
	{
		if (isset($_POST['cwd_v2_pay_credit_balance']) && is_user_logged_in()) {
			$roles = (array) wp_get_current_user()->roles;
			if (! in_array('credit_account', $roles, true) && ! current_user_can('manage_options')) {
				wc_add_notice(__('You are not authorized to make credit account payments.', 'custom-woo-dashboard'), 'error');
				return;
			}
			$nonce = isset($_POST['cwd_v2_pay_credit_nonce']) ? sanitize_text_field(wp_unslash($_POST['cwd_v2_pay_credit_nonce'])) : '';
			if (! wp_verify_nonce($nonce, 'cwd_v2_pay_credit_action')) {
				wc_add_notice(__('Security check failed.', 'custom-woo-dashboard'), 'error');
				return;
			}

			$product_id = (int) self::get_credit_payment_product_id();
			if (! $product_id) {
				wc_add_notice(__('Credit payment product not configured.', 'custom-woo-dashboard'), 'error');
				return;
			}

			// 1. Customer selected specific credit orders to pay off
			if (! empty($_POST['cwd_v2_selected_order_ids']) || ! empty($_POST['cwd_v2_pay_selected_orders'])) {
				$selected_ids = array_filter(array_map('absint', (array) ($_POST['cwd_v2_selected_order_ids'] ?? array())));
				$valid_order_ids = array();
				$calculated_order_amount = 0.0;
				$current_uid = get_current_user_id();

				foreach ($selected_ids as $sid) {
					$ord = wc_get_order($sid);
					if ($ord && (int) $ord->get_user_id() === $current_uid && $ord->get_meta('_credit_order_settled') !== 'yes') {
						$valid_order_ids[] = $sid;
						$calculated_order_amount += (float) $ord->get_total();
					}
				}

				if (empty($valid_order_ids) || $calculated_order_amount <= 0) {
					wc_add_notice(__('Please select at least one unsettled credit order to pay off.', 'custom-woo-dashboard'), 'error');
					return;
				}

				$amount = round($calculated_order_amount, 2);
				$cart_item_data = array(
					'cwd_v2_custom_price'      => $amount,
					'cwd_v2_settled_order_ids' => $valid_order_ids,
				);
			} else {
				// 2. Standard balance or invoice payment
				$amount = round((float) wc_format_decimal(wp_unslash($_POST['cwd_v2_pay_amount'] ?? 0)), 2);
				if ($amount <= 0) {
					wc_add_notice(__('Please enter a valid amount.', 'custom-woo-dashboard'), 'error');
					return;
				}

				$cart_item_data = array('cwd_v2_custom_price' => $amount);

				if (! empty($_POST['cwd_v2_pay_invoice_id'])) {
					$invoice_id = absint($_POST['cwd_v2_pay_invoice_id']);
					$invoice    = CWD_V2_Invoices::get_invoice($invoice_id, get_current_user_id());
					$amount_due = $invoice ? max(0, (float) $invoice->amount_total - (float) $invoice->amount_paid) : 0;
					$current_balance = (float) get_user_meta(get_current_user_id(), '_credit_balance', true);

					if (! $invoice || CWD_V2_Invoices::STATUS_UNPAID !== $invoice->status || $amount > round($amount_due, 2) || $amount > round($current_balance, 2)) {
						wc_add_notice(__('This invoice is no longer available to pay.', 'custom-woo-dashboard'), 'error');
						return;
					}

					$cart_item_data['cwd_v2_invoice_id'] = $invoice_id;
				} elseif ($amount > (float) get_user_meta(get_current_user_id(), '_credit_balance', true)) {
					wc_add_notice(__('The payment amount cannot exceed your outstanding balance.', 'custom-woo-dashboard'), 'error');
					return;
				}
			}

			// Empty cart to ensure only this payment is processed
			WC()->cart->empty_cart();

			// Add product to cart with custom price data
			WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);

			// Redirect to checkout
			wp_safe_redirect(wc_get_checkout_url());
			exit;
		}
	}

	public static function add_payment_item_metadata($item, $cart_item_key, $values, $order)
	{
		if (! empty($values['cwd_v2_invoice_id'])) {
			$item->add_meta_data('cwd_v2_invoice_id', absint($values['cwd_v2_invoice_id']), true);
		}

		if (! empty($values['cwd_v2_settled_order_ids'])) {
			$item->add_meta_data('cwd_v2_settled_order_ids', implode(',', array_map('absint', (array) $values['cwd_v2_settled_order_ids'])), true);
		}

		if (isset($values['cwd_v2_custom_price'])) {
			$item->add_meta_data('cwd_v2_payment_amount', round((float) $values['cwd_v2_custom_price'], 2), true);
		}
	}

	public static function set_credit_payment_price($cart_obj)
	{
		if (is_admin() && ! defined('DOING_AJAX')) {
			return;
		}

		foreach ($cart_obj->get_cart() as $key => $value) {
			if (isset($value['cwd_v2_custom_price'])) {
				$value['data']->set_price($value['cwd_v2_custom_price']);
			}
		}
	}

	public static function reduce_credit_balance_on_payment($order_id)
	{
		$order = wc_get_order($order_id);
		if (! $order) return;

		// Check if already processed to avoid double reduction
		if ($order->get_meta('_cwd_v2_credit_payment_processed')) {
			return;
		}

		$product_id = (int) get_option('cwd_v2_credit_payment_product_id');
		$is_credit_payment = false;
		$payment_amount = 0;

		$invoice_id = 0;
		$settled_order_ids = array();

		foreach ($order->get_items() as $item) {
			if ($item->get_product_id() === $product_id) {
				$is_credit_payment = true;
				$payment_amount = round((float) $order->get_total(), 2);

				$item_invoice_id = $item->get_meta('cwd_v2_invoice_id');
				if ($item_invoice_id) {
					$invoice_id = absint($item_invoice_id);
				}

				$item_settled = $item->get_meta('cwd_v2_settled_order_ids');
				if (! empty($item_settled)) {
					$settled_order_ids = array_filter(array_map('absint', explode(',', (string) $item_settled)));
				}
			}
		}

		if ($is_credit_payment) {
			$user_id = $order->get_user_id();
			if ($user_id) {
				global $wpdb;
				$wpdb->query('START TRANSACTION');
				$wpdb->get_var($wpdb->prepare('SELECT ID FROM ' . $wpdb->users . ' WHERE ID = %d FOR UPDATE', (int) $user_id));
				$current_balance = (float) get_user_meta($user_id, '_credit_balance', true);
				if ($payment_amount <= 0) {
					$wpdb->query('ROLLBACK');
					return;
				}
				if (empty($settled_order_ids) && $payment_amount > $current_balance) {
					$wpdb->query('ROLLBACK');
					return;
				}

				$payment_applied = true;
				if ($invoice_id) {
					$payment_applied = CWD_V2_Invoices::apply_invoice_payment($invoice_id, $user_id, $payment_amount);
				}

				if (! $payment_applied) {
					$wpdb->query('ROLLBACK');
					return;
				}

				// If specific orders were settled, mark them and settle any linked invoice
				if (! empty($settled_order_ids)) {
					foreach ($settled_order_ids as $soid) {
						$so = wc_get_order($soid);
						if ($so) {
							$so->update_meta_data('_credit_order_settled', 'yes');
							$so->update_meta_data('_credit_settlement_order_id', $order_id);
							$so->update_meta_data('_credit_settled_at', current_time('mysql'));
							$so->add_order_note(sprintf(__('Order credit balance settled via payment order #%d.', 'custom-woo-dashboard'), $order_id));
							$so->save();
						}
						// Settle invoice if exists in CWD_V2_Invoices
						if (class_exists('CWD_V2_Invoices')) {
							$inv = CWD_V2_Invoices::get_invoices_for_order($soid);
							if ($inv && $inv->status !== CWD_V2_Invoices::STATUS_PAID) {
								$due = max(0, (float) $inv->amount_total - (float) $inv->amount_paid);
								CWD_V2_Invoices::apply_invoice_payment($inv->id, $user_id, $due);
							}
						}
					}
				}

				$new_balance = max(0, $current_balance - $payment_amount);
				self::sync_user_credit_balance($user_id, $new_balance);

				if ($invoice_id) {
					$ledger_result = CWD_V2_Account_Ledger::record(
						$user_id,
						CWD_V2_Account_Ledger::TYPE_PAYMENT,
						$payment_amount,
						'invoice',
						$invoice_id,
						sprintf(__('Payment for invoice #%d', 'custom-woo-dashboard'), $invoice_id)
					);
				} elseif (! empty($settled_order_ids)) {
					$order_list_str = '#' . implode(', #', $settled_order_ids);
					$ledger_result = CWD_V2_Account_Ledger::record(
						$user_id,
						CWD_V2_Account_Ledger::TYPE_PAYMENT,
						$payment_amount,
						'order',
						$order_id,
						sprintf(__('Settlement payoff for credit order(s) %s via payment order #%d', 'custom-woo-dashboard'), $order_list_str, $order_id)
					);
				} else {
					$ledger_result = CWD_V2_Account_Ledger::record(
						$user_id,
						CWD_V2_Account_Ledger::TYPE_PAYMENT,
						$payment_amount,
						'order',
						$order_id,
						sprintf(__('Payment made via order #%d', 'custom-woo-dashboard'), $order_id)
					);
				}

				if (false === $ledger_result) {
					$wpdb->query('ROLLBACK');
					return;
				}
				$wpdb->query('COMMIT');

				if (class_exists('CWD_V2_Invoices')) {
					CWD_V2_Invoices::update_user_earliest_due_date($user_id);
				}

				// Mark as processed
				$order->update_meta_data('_cwd_v2_credit_payment_processed', 'yes');
				$order->save();
			}
		}

		// Handle optional checkout credit balance payoff
		$payoff_amount = (float) $order->get_meta('_cwd_payoff_credit_balance_amount');
		if ($payoff_amount > 0 && ! $order->get_meta('_cwd_payoff_balance_processed')) {
			$user_id = $order->get_user_id();
			if ($user_id) {
				$curr_bal = self::get_user_credit_balance($user_id);
				$new_bal  = max(0, $curr_bal - $payoff_amount);
				self::sync_user_credit_balance($user_id, $new_bal);
				if (class_exists('CWD_V2_Account_Ledger')) {
					CWD_V2_Account_Ledger::record(
						$user_id,
						CWD_V2_Account_Ledger::TYPE_PAYMENT,
						$payoff_amount,
						'order',
						$order->get_id(),
						sprintf(__('Checkout payoff of due credit balance via order #%d', 'custom-woo-dashboard'), $order->get_id())
					);
				}
				if (class_exists('CWD_V2_Invoices')) {
					CWD_V2_Invoices::apply_fifo_payment_to_unpaid_invoices($user_id, $payoff_amount);
					CWD_V2_Invoices::update_user_earliest_due_date($user_id);
				}
				$order->update_meta_data('_cwd_payoff_balance_processed', 'yes');
				$order->add_order_note(sprintf(__('Settled due credit balance of %s via checkout payoff on this order.', 'custom-woo-dashboard'), wc_price($payoff_amount)));
				$order->save();
			}
		}
	}

	/**
	 * Render optional credit balance payoff checkbox at checkout
	 */
	public static function render_checkout_credit_payoff_option()
	{
		if (! is_user_logged_in()) {
			return;
		}

		$user_id = get_current_user_id();
		$roles   = (array) wp_get_current_user()->roles;
		if (! in_array('credit_account', $roles, true) && ! current_user_can('manage_options')) {
			return;
		}

		// Don't render if paying credit balance specifically via the credit payment product
		$product_id = (int) self::get_credit_payment_product_id();
		if (isset(WC()->cart) && WC()->cart) {
			foreach (WC()->cart->get_cart() as $cart_item) {
				if ($product_id && (int) ($cart_item['product_id'] ?? 0) === $product_id) {
					return;
				}
			}
		}

		$credit_balance = self::get_user_credit_balance($user_id);
		$due_credit     = class_exists('CWD_V2_Invoices') ? CWD_V2_Invoices::get_user_due_credit_amount($user_id) : 0.0;
		$payoff_amount  = ($due_credit > 0.01) ? $due_credit : $credit_balance;

		if ($payoff_amount <= 0.01) {
			return;
		}

		$due_date   = (string) get_user_meta($user_id, '_credit_due_date', true);
		$is_checked = (bool) (WC()->session ? WC()->session->get('cwd_payoff_credit_balance', false) : false);
		?>
		<div class="cwd-credit-payoff-checkout-box" style="margin: 16px 0; padding: 14px 16px; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px;">
			<label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; margin: 0; font-size: 14px; color: #0f172a;">
				<input type="checkbox" name="cwd_payoff_credit_balance" id="cwd_payoff_credit_balance" value="1" <?php checked($is_checked, true); ?> style="margin-top: 3px;" onchange="jQuery('input[name=\'cwd_payoff_credit_balance\']').prop('checked', this.checked); jQuery('body').trigger('update_checkout');" />
				<span>
					<strong><?php printf(esc_html__('Pay due credit balance (%s) with this order', 'custom-woo-dashboard'), wp_strip_all_tags(wc_price($payoff_amount))); ?></strong>
					<?php if (! empty($due_date)) : ?>
						<span style="display: block; font-size: 12px; color: #64748b; margin-top: 2px;">
							<?php printf(esc_html__('Payment due date: %s. Tick this box to clear your due balance now via card or direct payment.', 'custom-woo-dashboard'), esc_html($due_date)); ?>
						</span>
					<?php else : ?>
						<span style="display: block; font-size: 12px; color: #64748b; margin-top: 2px;">
							<?php esc_html_e('Leave unchecked to pay only for the items currently in your cart according to your standard trade terms.', 'custom-woo-dashboard'); ?>
						</span>
					<?php endif; ?>
				</span>
			</label>
		</div>
		<?php
	}

	/**
	 * Handle AJAX update of the checkout payoff preference
	 */
	public static function handle_checkout_update_payoff_preference($post_data)
	{
		if (! WC()->session) {
			return;
		}

		$params = array();
		wp_parse_str($post_data, $params);

		$payoff = ! empty($params['cwd_payoff_credit_balance']);
		WC()->session->set('cwd_payoff_credit_balance', $payoff);
	}

	/**
	 * Apply checkout payoff fee to cart total if selected
	 */
	public static function apply_checkout_credit_payoff_fee($cart)
	{
		if (is_admin() && ! defined('DOING_AJAX')) {
			return;
		}

		if (! is_user_logged_in() || ! WC()->session) {
			return;
		}

		if (! WC()->session->get('cwd_payoff_credit_balance', false)) {
			return;
		}

		$product_id = (int) self::get_credit_payment_product_id();
		foreach ($cart->get_cart() as $cart_item) {
			if ($product_id && (int) ($cart_item['product_id'] ?? 0) === $product_id) {
				return;
			}
		}

		$user_id        = get_current_user_id();
		$credit_balance = self::get_user_credit_balance($user_id);
		$due_credit     = class_exists('CWD_V2_Invoices') ? CWD_V2_Invoices::get_user_due_credit_amount($user_id) : 0.0;
		$payoff_amount  = ($due_credit > 0.01) ? $due_credit : $credit_balance;

		if ($payoff_amount > 0.01) {
			$cart->add_fee(__('Due Credit Balance Payoff', 'custom-woo-dashboard'), $payoff_amount, false);
		}
	}

	/**
	 * Save payoff meta to order upon creation
	 */
	public static function save_checkout_credit_payoff_meta($order, $data)
	{
		if (isset(WC()->session) && WC()->session->get('cwd_payoff_credit_balance', false)) {
			$user_id = $order->get_user_id();
			if ($user_id) {
				$credit_balance = self::get_user_credit_balance($user_id);
				$due_credit     = class_exists('CWD_V2_Invoices') ? CWD_V2_Invoices::get_user_due_credit_amount($user_id) : 0.0;
				$payoff_amount  = ($due_credit > 0.01) ? $due_credit : $credit_balance;

				if ($payoff_amount > 0.01) {
					$order->update_meta_data('_cwd_payoff_credit_balance_amount', $payoff_amount);
				}
			}
			WC()->session->set('cwd_payoff_credit_balance', false);
		}
	}

	public static function handle_credit_increase_request()
	{
		if ((isset($_POST['cwd_v2_request_increase']) || isset($_POST['cwd_v2_requested_amount'])) && is_user_logged_in()) {
			$nonce = isset($_POST['cwd_v2_request_increase_nonce']) ? sanitize_text_field(wp_unslash($_POST['cwd_v2_request_increase_nonce'])) : '';
			if (! wp_verify_nonce($nonce, 'cwd_v2_request_increase_action')) {
				wc_add_notice(__('Security check failed.', 'custom-woo-dashboard'), 'error');
				return;
			}

			$current_user = wp_get_current_user();
			$requested_amount = sanitize_text_field(wp_unslash($_POST['cwd_v2_requested_amount'] ?? ''));
			$reason = sanitize_textarea_field(wp_unslash($_POST['cwd_v2_request_reason'] ?? ''));
			if (! is_numeric($requested_amount) || (float) $requested_amount <= 0) {
				wc_add_notice(__('Enter a valid positive credit limit.', 'custom-woo-dashboard'), 'error');
				return;
			}

			// Check if user already has an active pending request or submitted very recently
			if (class_exists('CWD_V2_Trade_Applications')) {
				global $wpdb;
				$apps_table = CWD_V2_Trade_Applications::get_table_name();
				$existing_pending = $wpdb->get_var($wpdb->prepare(
					"SELECT id FROM {$apps_table} WHERE user_id = %d AND status = %s AND forminator_form_id = 0 LIMIT 1",
					$current_user->ID,
					'pending'
				));
				if ($existing_pending) {
					wc_add_notice(__('You already have a credit increase request under review.', 'custom-woo-dashboard'), 'notice');
					$redirect_url = wp_get_referer() ?: wc_get_endpoint_url('credit', '', wc_get_page_permalink('myaccount'));
					wp_safe_redirect($redirect_url);
					exit;
				}
			}

			$admin_email = get_option('admin_email');
			$subject = sprintf(__('Credit Limit Increase Request from %s', 'custom-woo-dashboard'), $current_user->display_name);

			$message = sprintf(__("Customer: %s (%s)\n", 'custom-woo-dashboard'), $current_user->display_name, $current_user->user_email);
			$message .= sprintf(__("Requested New Limit: %s\n", 'custom-woo-dashboard'), $requested_amount);
			$message .= sprintf(__("Reason:\n%s\n", 'custom-woo-dashboard'), $reason);

			wp_mail($admin_email, $subject, $message);

			// Also record in Trade Applications queue for admin review & approval
			if (class_exists('CWD_V2_Trade_Applications')) {
				CWD_V2_Trade_Applications::record_credit_increase_request(
					$current_user->ID,
					(float) $requested_amount,
					$reason
				);
			}

			wc_add_notice(__('Your request for a credit limit increase has been submitted for review.', 'custom-woo-dashboard'), 'success');

			// Post-Redirect-Get: Redirect to GET so refreshing page never re-submits POST form
			$redirect_url = wp_get_referer() ?: wc_get_endpoint_url('credit', '', wc_get_page_permalink('myaccount'));
			wp_safe_redirect($redirect_url);
			exit;
		}
	}

	/**
	 * Get standard UK counties grouped by nation.
	 *
	 * @return array
	 */
	public static function get_uk_counties()
	{
		return array(
			'England' => array(
				'Bedfordshire', 'Berkshire', 'Bristol', 'Buckinghamshire', 'Cambridgeshire',
				'Cheshire', 'City of London', 'Cornwall', 'Cumbria', 'Derbyshire',
				'Devon', 'Dorset', 'Durham', 'East Riding of Yorkshire', 'East Sussex',
				'Essex', 'Gloucestershire', 'Greater London', 'Greater Manchester', 'Hampshire',
				'Herefordshire', 'Hertfordshire', 'Isle of Wight', 'Kent', 'Lancashire',
				'Leicestershire', 'Lincolnshire', 'Merseyside', 'Norfolk', 'North Somerset',
				'North Yorkshire', 'Northamptonshire', 'Northumberland', 'Nottinghamshire', 'Oxfordshire',
				'Rutland', 'Shropshire', 'Somerset', 'South Yorkshire', 'Staffordshire',
				'Suffolk', 'Surrey', 'Tyne and Wear', 'Warwickshire', 'West Midlands',
				'West Sussex', 'West Yorkshire', 'Wiltshire', 'Worcestershire',
			),
			'Scotland' => array(
				'Aberdeenshire', 'Angus', 'Argyll and Bute', 'Ayrshire', 'Banffshire',
				'Berwickshire', 'Caithness', 'Clackmannanshire', 'Dumfries and Galloway', 'Dunbartonshire',
				'East Lothian', 'Falkirk', 'Fife', 'Highland', 'Inverclyde',
				'Midlothian', 'Moray', 'North Ayrshire', 'North Lanarkshire', 'Orkney',
				'Perth and Kinross', 'Renfrewshire', 'Scottish Borders', 'Shetland', 'South Ayrshire',
				'South Lanarkshire', 'Stirling', 'West Dunbartonshire', 'West Lothian', 'Western Isles',
			),
			'Wales' => array(
				'Anglesey', 'Blaenau Gwent', 'Bridgend', 'Caerphilly', 'Cardiff',
				'Carmarthenshire', 'Ceredigion', 'Conwy', 'Denbighshire', 'Flintshire',
				'Glamorgan', 'Gwynedd', 'Merthyr Tydfil', 'Monmouthshire', 'Neath Port Talbot',
				'Newport', 'Pembrokeshire', 'Powys', 'Rhondda Cynon Taf', 'Swansea',
				'Torfaen', 'Vale of Glamorgan', 'Wrexham',
			),
			'Northern Ireland' => array(
				'County Antrim', 'County Armagh', 'County Down', 'County Fermanagh', 'County Londonderry', 'County Tyrone',
			),
		);
	}

	/**
	 * Handle new trade account application submission from customer credit dashboard.
	 */
	public static function handle_trade_application_submission()
	{
		if (isset($_POST['cwd_v2_submit_trade_app']) && is_user_logged_in()) {
			$nonce = isset($_POST['cwd_v2_apply_trade_nonce']) ? sanitize_text_field(wp_unslash($_POST['cwd_v2_apply_trade_nonce'])) : '';
			if (! wp_verify_nonce($nonce, 'cwd_v2_apply_trade_action')) {
				wc_add_notice(__('Security check failed. Please try again.', 'custom-woo-dashboard'), 'error');
				return;
			}

			$current_user = wp_get_current_user();
			$user_id      = (int) $current_user->ID;

			// Extract all form fields
			$company_name            = sanitize_text_field(wp_unslash($_POST['cwd_v2_company_name'] ?? ''));
			$company_reg_number      = sanitize_text_field(wp_unslash($_POST['cwd_v2_company_reg_number'] ?? ''));
			$vat_number              = sanitize_text_field(wp_unslash($_POST['cwd_v2_vat_number'] ?? '')); // optional
			$parent_company          = sanitize_text_field(wp_unslash($_POST['cwd_v2_parent_company'] ?? '')); // optional
			$business_sector         = sanitize_text_field(wp_unslash($_POST['cwd_v2_business_sector'] ?? ''));
			$trading_duration        = sanitize_text_field(wp_unslash($_POST['cwd_v2_trading_duration'] ?? ''));
			$requested_amount        = sanitize_text_field(wp_unslash($_POST['cwd_v2_requested_limit'] ?? ''));
			$monthly_spend_raw       = sanitize_text_field(wp_unslash($_POST['cwd_v2_estimated_monthly_spend'] ?? ''));
			$street_address          = sanitize_text_field(wp_unslash($_POST['cwd_v2_street_address'] ?? ''));
			$city                    = sanitize_text_field(wp_unslash($_POST['cwd_v2_city'] ?? ''));
			$county                  = sanitize_text_field(wp_unslash($_POST['cwd_v2_county'] ?? ''));
			$postcode                = sanitize_text_field(wp_unslash($_POST['cwd_v2_postcode'] ?? ''));
			$phone                   = sanitize_text_field(wp_unslash($_POST['cwd_v2_phone'] ?? ''));
			$email                   = sanitize_email(wp_unslash($_POST['cwd_v2_email'] ?? $current_user->user_email));
			$trade_ref_name          = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_name'] ?? ''));
			$trade_ref_address       = sanitize_textarea_field(wp_unslash($_POST['cwd_v2_trade_ref_address'] ?? ''));
			$trade_ref_tel           = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_tel'] ?? ''));
			$trade_ref_2_name        = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_2_name'] ?? ''));
			$trade_ref_2_address     = sanitize_textarea_field(wp_unslash($_POST['cwd_v2_trade_ref_2_address'] ?? ''));
			$trade_ref_2_tel         = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_2_tel'] ?? ''));
			$trade_ref_3_name        = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_3_name'] ?? ''));
			$trade_ref_3_address     = sanitize_textarea_field(wp_unslash($_POST['cwd_v2_trade_ref_3_address'] ?? ''));
			$trade_ref_3_tel         = sanitize_text_field(wp_unslash($_POST['cwd_v2_trade_ref_3_tel'] ?? ''));
			$signatory_name          = sanitize_text_field(wp_unslash($_POST['cwd_v2_signatory_name'] ?? ''));
			$signatory_title         = sanitize_text_field(wp_unslash($_POST['cwd_v2_signatory_title'] ?? ''));
			$terms_accepted          = ! empty($_POST['cwd_v2_terms_accepted']);
			$signature_data          = trim((string) wp_unslash($_POST['cwd_v2_signature_data'] ?? ''));

			// Validation: Mandatory and format checks
			$errors = array();

			// 1. Company Name
			if (empty($company_name)) {
				$errors[] = __('Company name is required.', 'custom-woo-dashboard');
			}

			// 2. UK Companies House Company Registration Number (CRN)
			$clean_crn = strtoupper(trim(preg_replace('/[\s\-]/', '', $company_reg_number)));
			if (empty($clean_crn)) {
				$errors[] = __('Company registration number is required.', 'custom-woo-dashboard');
			} else {
				// If 6 or 7 digits entered, Companies House standard is to zero-pad on left to 8 digits
				if (ctype_digit($clean_crn) && strlen($clean_crn) >= 6 && strlen($clean_crn) < 8) {
					$clean_crn = str_pad($clean_crn, 8, '0', STR_PAD_LEFT);
				}
				// Standard: 8 digits, or 2 letters followed by 6 digits/characters (e.g. SC123456, NI123456, OC123456)
				if (! preg_match('/^(?:[0-9]{8}|[A-Z]{2}[0-9]{6}|[A-Z][0-9]{7})$/', $clean_crn)) {
					$errors[] = __('Company Registration Number must be a valid 8-character Companies House number (e.g. 12345678, 01234567, or SC123456).', 'custom-woo-dashboard');
				} else {
					$company_reg_number = $clean_crn;
				}
			}

			// 3. UK VAT Number (HMRC standard format, optional)
			if (! empty($vat_number)) {
				$clean_vat = strtoupper(trim(preg_replace('/[\s\-]/', '', $vat_number)));
				// Standard: 9 digits, 12 digits (branch traders), or GD/HA prefix + 3 digits, with optional GB prefix
				if (! preg_match('/^(?:GB)?(?:[0-9]{9}|[0-9]{12}|(?:GD|HA)[0-9]{3})$/', $clean_vat)) {
					$errors[] = __('Please enter a valid UK VAT number (e.g. GB123456789 or 9 digits), or leave blank if not VAT registered.', 'custom-woo-dashboard');
				} else {
					// Normalize to include standard GB prefix
					if (strpos($clean_vat, 'GB') !== 0 && ! in_array(substr($clean_vat, 0, 2), array('GD', 'HA'), true)) {
						$clean_vat = 'GB' . $clean_vat;
					}
					$vat_number = $clean_vat;
				}
			}

			// 4. Contact Phone (Must always begin with UK country code +44)
			$phone = trim($phone);
			if (empty($phone)) {
				$errors[] = __('Contact phone number is required.', 'custom-woo-dashboard');
			} elseif (strpos($phone, '+44') !== 0) {
				$errors[] = __('Contact phone number must begin with the UK country code (+44), e.g. +44 7123 456789 or +44 20 7123 4567.', 'custom-woo-dashboard');
			} else {
				// Strip +44, spaces, hyphens, and optional (0)
				$sub_phone = preg_replace('/[^0-9]/', '', substr($phone, 3));
				if (strpos($sub_phone, '0') === 0) {
					$sub_phone = substr($sub_phone, 1);
				}
				// Valid UK landline/mobile subscriber numbers are 9 or 10 digits
				if (strlen($sub_phone) < 9 || strlen($sub_phone) > 10) {
					$errors[] = __('Please enter a valid UK telephone number following +44 (9 or 10 digits, e.g. +44 7123 456789 or +44 20 7123 4567).', 'custom-woo-dashboard');
				} else {
					// Normalize format: +44 XXXXXXXXXX
					$phone = '+44 ' . $sub_phone;
				}
			}

			// 5. Business Sector & Duration
			if (empty($business_sector)) {
				$errors[] = __('Business sector / industry is required.', 'custom-woo-dashboard');
			}
			if (empty($trading_duration)) {
				$errors[] = __('Company trading duration is required.', 'custom-woo-dashboard');
			}

			// 6. Registered Address
			if (empty($street_address)) {
				$errors[] = __('Street address is required.', 'custom-woo-dashboard');
			}
			if (empty($city)) {
				$errors[] = __('Town / City is required.', 'custom-woo-dashboard');
			}

			// 7. County (Must be from official UK counties list)
			$all_counties_flat = array();
			foreach (self::get_uk_counties() as $c_list) {
				$all_counties_flat = array_merge($all_counties_flat, $c_list);
			}
			$all_counties_lower = array_map('strtolower', $all_counties_flat);
			if (empty($county)) {
				$errors[] = __('County is required. Please select a valid UK county.', 'custom-woo-dashboard');
			} elseif (! in_array(strtolower($county), $all_counties_lower, true) && ! in_array(strtolower('County ' . $county), $all_counties_lower, true)) {
				$errors[] = __('Please select a valid UK county from the list.', 'custom-woo-dashboard');
			}

			// 8. UK Postcode (Royal Mail / BS 7666 standard format)
			$clean_postcode = strtoupper(trim(preg_replace('/\s+/', ' ', $postcode)));
			if (empty($clean_postcode)) {
				$errors[] = __('UK Postcode is required.', 'custom-woo-dashboard');
			} else {
				$postcode_regex = '/^([Gg][Ii][Rr]\s?0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})$/';
				if (! preg_match($postcode_regex, $clean_postcode)) {
					$errors[] = __('Please enter a valid UK postcode (e.g. SW1A 1AA, EC1A 1BB, M1 1AE).', 'custom-woo-dashboard');
				} else {
					// Normalize with standard space between outward and inward code
					$no_space = str_replace(' ', '', $clean_postcode);
					$inward   = substr($no_space, -3);
					$outward  = substr($no_space, 0, -3);
					$postcode = $outward . ' ' . $inward;
				}
			}

			// 9. Contact Email
			if (empty($email) || ! is_email($email)) {
				$errors[] = __('A valid contact email address is required.', 'custom-woo-dashboard');
			}

			// 10. Trade References
			if (empty($trade_ref_name)) {
				$errors[] = __('Trade Reference 1 Name is required.', 'custom-woo-dashboard');
			}
			if (empty($trade_ref_address)) {
				$errors[] = __('Trade Reference 1 Address is required.', 'custom-woo-dashboard');
			}
			$trade_ref_tel = trim($trade_ref_tel);
			if (empty($trade_ref_tel)) {
				$errors[] = __('Trade Reference 1 Telephone is required.', 'custom-woo-dashboard');
			} elseif (strpos($trade_ref_tel, '+44') !== 0) {
				$errors[] = __('Trade Reference 1 Telephone must begin with the UK country code (+44), e.g. +44 7123 456789 or +44 20 7123 4567.', 'custom-woo-dashboard');
			} else {
				$sub_ref1 = preg_replace('/[^0-9]/', '', substr($trade_ref_tel, 3));
				if (strpos($sub_ref1, '0') === 0) {
					$sub_ref1 = substr($sub_ref1, 1);
				}
				if (strlen($sub_ref1) < 9 || strlen($sub_ref1) > 10) {
					$errors[] = __('Please enter a valid UK telephone number following +44 for Trade Reference 1 (9 or 10 digits, e.g. +44 7123 456789).', 'custom-woo-dashboard');
				} else {
					$trade_ref_tel = '+44 ' . $sub_ref1;
				}
			}

			// Trade Reference 2 (if entered)
			$trade_ref_2_tel = trim($trade_ref_2_tel);
			if (! empty($trade_ref_2_name) || ! empty($trade_ref_2_address) || ! empty($trade_ref_2_tel)) {
				if (empty($trade_ref_2_tel)) {
					$errors[] = __('Trade Reference 2 Telephone is required if Reference 2 details are provided.', 'custom-woo-dashboard');
				} elseif (strpos($trade_ref_2_tel, '+44') !== 0) {
					$errors[] = __('Trade Reference 2 Telephone must begin with the UK country code (+44), e.g. +44 7123 456789.', 'custom-woo-dashboard');
				} else {
					$sub_ref2 = preg_replace('/[^0-9]/', '', substr($trade_ref_2_tel, 3));
					if (strpos($sub_ref2, '0') === 0) {
						$sub_ref2 = substr($sub_ref2, 1);
					}
					if (strlen($sub_ref2) < 9 || strlen($sub_ref2) > 10) {
						$errors[] = __('Please enter a valid UK telephone number following +44 for Trade Reference 2 (9 or 10 digits).', 'custom-woo-dashboard');
					} else {
						$trade_ref_2_tel = '+44 ' . $sub_ref2;
					}
				}
			}

			// Trade Reference 3 (if entered)
			$trade_ref_3_tel = trim($trade_ref_3_tel);
			if (! empty($trade_ref_3_name) || ! empty($trade_ref_3_address) || ! empty($trade_ref_3_tel)) {
				if (empty($trade_ref_3_tel)) {
					$errors[] = __('Trade Reference 3 Telephone is required if Reference 3 details are provided.', 'custom-woo-dashboard');
				} elseif (strpos($trade_ref_3_tel, '+44') !== 0) {
					$errors[] = __('Trade Reference 3 Telephone must begin with the UK country code (+44), e.g. +44 7123 456789.', 'custom-woo-dashboard');
				} else {
					$sub_ref3 = preg_replace('/[^0-9]/', '', substr($trade_ref_3_tel, 3));
					if (strpos($sub_ref3, '0') === 0) {
						$sub_ref3 = substr($sub_ref3, 1);
					}
					if (strlen($sub_ref3) < 9 || strlen($sub_ref3) > 10) {
						$errors[] = __('Please enter a valid UK telephone number following +44 for Trade Reference 3 (9 or 10 digits).', 'custom-woo-dashboard');
					} else {
						$trade_ref_3_tel = '+44 ' . $sub_ref3;
					}
				}
			}

			// 11. Credit Limit & Spend
			$requested_limit_val = (float) preg_replace('/[^0-9.]/', '', (string) $requested_amount);
			if ($requested_limit_val <= 0) {
				$errors[] = __('Requested credit limit must be greater than zero.', 'custom-woo-dashboard');
			}

			$monthly_spend_val = (float) preg_replace('/[^0-9.]/', '', (string) $monthly_spend_raw);
			if ($monthly_spend_val <= 0) {
				$errors[] = __('Estimated monthly spend must be greater than zero.', 'custom-woo-dashboard');
			}

			// 12. Trade Credit Agreement & Authorised Signature
			if (empty($terms_accepted)) {
				$errors[] = __('You must read and agree to the Trade Credit Terms & Declaration.', 'custom-woo-dashboard');
			}
			if (empty($signatory_name)) {
				$errors[] = __('Authorised signatory full name is required.', 'custom-woo-dashboard');
			}
			if (empty($signatory_title)) {
				$errors[] = __('Authorised signatory job title / position is required.', 'custom-woo-dashboard');
			}
			if (empty($signature_data) || strpos($signature_data, 'data:image/png;base64,') !== 0) {
				$errors[] = __('Please draw your signature in the signature pad box before submitting.', 'custom-woo-dashboard');
			}

			if (! empty($errors)) {
				foreach ($errors as $err) {
					wc_add_notice($err, 'error');
				}
				return;
			}

			if (class_exists('CWD_V2_Trade_Applications')) {
				global $wpdb;
				$apps_table = CWD_V2_Trade_Applications::get_table_name();
				CWD_V2_Trade_Applications::ensure_table_exists();

				// Check if pending application already exists
				$existing_pending = $wpdb->get_var($wpdb->prepare(
					"SELECT id FROM {$apps_table} WHERE (user_id = %d OR applicant_email = %s) AND status = %s LIMIT 1",
					$user_id,
					$email,
					'pending'
				));

				if ($existing_pending) {
					wc_add_notice(__('You already have a trade credit application under review.', 'custom-woo-dashboard'), 'notice');
					$redirect_url = wp_get_referer() ?: wc_get_endpoint_url('credit', '', wc_get_page_permalink('myaccount'));
					wp_safe_redirect($redirect_url);
					exit;
				}

				// Process signature image: decode Base64 and write PNG file to wp-content/uploads/trade-signatures/
				$signature_url = '';
				if (strpos($signature_data, 'data:image/png;base64,') === 0) {
					$b64 = substr($signature_data, strlen('data:image/png;base64,'));
					$img_bytes = base64_decode($b64);
					if ($img_bytes !== false) {
						$upload_dir = wp_upload_dir();
						$sig_dir = $upload_dir['basedir'] . '/trade-signatures';
						if (! file_exists($sig_dir)) {
							wp_mkdir_p($sig_dir);
							@file_put_contents($sig_dir . '/index.html', '');
						}
						$filename = 'sig_' . $user_id . '_' . time() . '_' . wp_generate_password(6, false) . '.png';
						$filepath = $sig_dir . '/' . $filename;
						if (@file_put_contents($filepath, $img_bytes)) {
							$signature_url = $upload_dir['baseurl'] . '/trade-signatures/' . $filename;
						}
					}
				}

				$now       = current_time('mysql');
				$form_data = array(
					'company_name'            => $company_name,
					'company_reg_number'      => $company_reg_number,
					'vat_number'              => $vat_number,
					'parent_company'          => $parent_company,
					'business_sector'         => $business_sector,
					'trading_duration'        => $trading_duration,
					'requested_limit'         => $requested_limit_val,
					'estimated_monthly_spend' => $monthly_spend_val,
					'street_address'          => $street_address,
					'city'                    => $city,
					'county'                  => $county,
					'postcode'                => $postcode,
					'phone'                   => $phone,
					'applicant_email'         => $email,
					'trade_ref_name'          => $trade_ref_name,
					'trade_ref_address'       => $trade_ref_address,
					'trade_ref_tel'           => $trade_ref_tel,
					'trade_ref_2_name'        => $trade_ref_2_name,
					'trade_ref_2_address'     => $trade_ref_2_address,
					'trade_ref_2_tel'         => $trade_ref_2_tel,
					'trade_ref_3_name'        => $trade_ref_3_name,
					'trade_ref_3_address'     => $trade_ref_3_address,
					'trade_ref_3_tel'         => $trade_ref_3_tel,
					'signatory_name'          => $signatory_name,
					'signatory_title'         => $signatory_title,
					'signature_url'           => $signature_url,
					'signature_data'          => ! empty($signature_url) ? '' : $signature_data,
					'signed_at'               => $now,
					'signer_ip'               => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
					'terms_accepted'          => true,
					'source'                  => 'customer_credit_dashboard',
				);

				$insert_data = array(
					'forminator_form_id'  => 0,
					'forminator_entry_id' => 0,
					'applicant_email'     => sanitize_email($email),
					'applicant_name'      => sanitize_text_field($current_user->display_name),
					'company_name'        => $company_name,
					'phone'               => $phone,
					'requested_limit'     => $requested_limit_val,
					'form_data'           => wp_json_encode($form_data),
					'status'              => 'pending',
					'user_id'             => $user_id,
					'created_at'          => $now,
					'updated_at'          => $now,
				);

				$wpdb->insert($apps_table, $insert_data, array('%d', '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%d', '%s', '%s'));
				$app_id = $wpdb->insert_id;

				// Permanently store submitted information into user meta
				update_user_meta($user_id, 'billing_company', $company_name);
				update_user_meta($user_id, 'billing_phone', $phone);
				update_user_meta($user_id, 'billing_address_1', $street_address);
				update_user_meta($user_id, 'billing_city', $city);
				update_user_meta($user_id, 'billing_state', $county);
				update_user_meta($user_id, 'billing_postcode', $postcode);
				update_user_meta($user_id, '_company_reg_number', $company_reg_number);
				update_user_meta($user_id, '_vat_number', $vat_number);
				update_user_meta($user_id, '_parent_company', $parent_company);
				update_user_meta($user_id, '_business_sector', $business_sector);
				update_user_meta($user_id, '_trading_duration', $trading_duration);
				update_user_meta($user_id, '_estimated_monthly_spend', $monthly_spend_val);
				update_user_meta($user_id, '_trade_ref_name', $trade_ref_name);
				update_user_meta($user_id, '_trade_ref_address', $trade_ref_address);
				update_user_meta($user_id, '_trade_ref_tel', $trade_ref_tel);
				if (! empty($trade_ref_2_name)) {
					update_user_meta($user_id, '_trade_ref_2_name', $trade_ref_2_name);
					update_user_meta($user_id, '_trade_ref_2_address', $trade_ref_2_address);
					update_user_meta($user_id, '_trade_ref_2_tel', $trade_ref_2_tel);
				}
				if (! empty($trade_ref_3_name)) {
					update_user_meta($user_id, '_trade_ref_3_name', $trade_ref_3_name);
					update_user_meta($user_id, '_trade_ref_3_address', $trade_ref_3_address);
					update_user_meta($user_id, '_trade_ref_3_tel', $trade_ref_3_tel);
				}
				update_user_meta($user_id, '_trade_signatory_name', $signatory_name);
				update_user_meta($user_id, '_trade_signatory_title', $signatory_title);
				update_user_meta($user_id, '_trade_signature_url', $signature_url ?: $signature_data);
				update_user_meta($user_id, '_trade_signed_at', $now);

				// Only set credit limit/status to pending if this is a brand new applicant without active credit
				$is_active_existing = (float) get_user_meta($user_id, '_credit_limit', true) > 0 || in_array('credit_account', (array) $current_user->roles, true);
				if (! $is_active_existing) {
					update_user_meta($user_id, '_requested_credit_limit', $requested_limit_val);
					update_user_meta($user_id, '_credit_status', 'pending');
					update_user_meta($user_id, 'credit_status', 'pending');
				}

				// Forward to Credits plugin strictly with pending status (NO auto-approval)
				if ($app_id && class_exists('CWD_V2_Credits_Bridge')) {
					CWD_V2_Credits_Bridge::forward_application_to_credits_plugin(
						$app_id,
						$user_id,
						$email,
						$current_user->display_name,
						$company_name,
						$phone,
						$requested_limit_val,
						$form_data
					);
				}

				// Email notification to admin
				$admin_email = get_option('admin_email');
				$subject     = sprintf(__('New Trade Credit Application from %s (%s)', 'custom-woo-dashboard'), $company_name, $current_user->display_name);
				$body        = sprintf(
					__("A new comprehensive trade account application has been submitted:\n\n" .
					"Applicant: %s\n" .
					"Email: %s\n" .
					"Phone: %s\n" .
					"Company Name: %s\n" .
					"Company Reg No: %s\n" .
					"VAT No: %s\n" .
					"Parent Company: %s\n" .
					"Sector: %s\n" .
					"Trading Duration: %s\n" .
					"Registered Address: %s, %s, %s, %s\n" .
					"Requested Credit Limit: %s\n" .
					"Estimated Monthly Spend: %s\n\n" .
					"Trade Reference 1:\n" .
					"  Name: %s\n" .
					"  Address: %s\n" .
					"  Tel: %s\n\n" .
					"Review and approve/reject in WooCommerce > Trade & Credit Management > Applications Queue.\n", 'custom-woo-dashboard'),
					$current_user->display_name,
					$email,
					$phone,
					$company_name,
					$company_reg_number,
					$vat_number ?: 'N/A',
					$parent_company ?: 'N/A',
					$business_sector,
					$trading_duration,
					$street_address,
					$city,
					$county,
					$postcode,
					wc_price($requested_limit_val),
					wc_price($monthly_spend_val),
					$trade_ref_name,
					$trade_ref_address,
					$trade_ref_tel
				);
				wp_mail($admin_email, $subject, $body);

				wc_add_notice(__('Your trade credit application has been submitted and is currently pending review by our trade finance team.', 'custom-woo-dashboard'), 'success');

				$redirect_url = wp_get_referer() ?: wc_get_endpoint_url('credit', '', wc_get_page_permalink('myaccount'));
				wp_safe_redirect($redirect_url);
				exit;
			}
		}
	}

	/**
	 * Get the synchronized credit limit for a user across all meta sources
	 *
	 * @param int $user_id
	 * @return float
	 */
	public static function get_user_credit_limit($user_id)
	{
		$user_id = (int) $user_id;
		if (! $user_id) {
			return 0.0;
		}

		// 1. Authoritative check: If user already has an active credit limit or credit_account role, preserve it!
		$existing_limit = (float) get_user_meta($user_id, '_credit_limit', true);
		$user_obj       = get_userdata($user_id);
		$is_credit_user = ($user_obj && in_array('credit_account', (array) $user_obj->roles, true));

		if ($existing_limit > 0 || $is_credit_user) {
			return max(0.0, $existing_limit);
		}

		// Safeguard for new applicants only: If user has a pending trade application and NO approved limit,
		// their approved limit is strictly 0.00 until an admin manually approves them.
		if (class_exists('CWD_V2_Trade_Applications')) {
			global $wpdb;
			$apps_table = CWD_V2_Trade_Applications::get_table_name();
			if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $apps_table)) === $apps_table) {
				$email = $user_obj ? $user_obj->user_email : '';
				$has_approved = (int) $wpdb->get_var($wpdb->prepare(
					"SELECT COUNT(*) FROM {$apps_table}
					 WHERE (user_id = %d OR (applicant_email = %s AND applicant_email != '')) AND status = 'approved' AND approved_limit > 0",
					$user_id,
					$email
				));
				$has_pending = (int) $wpdb->get_var($wpdb->prepare(
					"SELECT COUNT(*) FROM {$apps_table}
					 WHERE (user_id = %d OR (applicant_email = %s AND applicant_email != '')) AND status = 'pending'",
					$user_id,
					$email
				));
				if ($has_pending > 0 && $has_approved === 0) {
					return 0.0;
				}
			}
		}

		// 2. Authoritative check: If positive _credit_limit is set in usermeta, return it immediately.
		if (metadata_exists('user', $user_id, '_credit_limit')) {
			$raw_limit = (float) get_user_meta($user_id, '_credit_limit', true);
			if ($raw_limit > 0) {
				return $raw_limit;
			}
		}

		// 3. Initial discovery: If _credit_limit is not set or zero, discover from other plugins/CPTs/applications
		$discovered_limit = 0.0;

		// Check all known credit plugin meta keys to discover existing limits
		$keys = array(
			'credit_limit',
			'_credits_limit',
			'credits_limit',
			'_fpc_credit_limit',
			'fpc_credit_limit',
			'_fp_credit_limit',
			'fp_credit_limit',
			'_user_credit_limit',
			'_wc_cs_credit_limit',
			'wc_cs_credit_limit',
			'_approved_credits',
			'approved_credits',
		);
		foreach ($keys as $k) {
			$val = (float) get_user_meta($user_id, $k, true);
			if ($val > $discovered_limit) {
				$discovered_limit = $val;
			}
		}

		// Check latest approved application in trade applications table
		if (class_exists('CWD_V2_Trade_Applications')) {
			global $wpdb;
			$apps_table = CWD_V2_Trade_Applications::get_table_name();
			$u = get_userdata($user_id);
			$email = $u ? $u->user_email : '';
			$app_limit = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT approved_limit FROM {$apps_table}
				 WHERE (user_id = %d OR (applicant_email = %s AND applicant_email != '')) AND status = %s AND approved_limit > 0
				 ORDER BY id DESC LIMIT 1",
				$user_id,
				$email,
				'approved'
			));
			if ($app_limit > $discovered_limit) {
				$discovered_limit = $app_limit;
			}
		}

		// Check external CPT posts in 'credits' / 'wc_cs_credits' / 'fpc_credits'
		global $wpdb;
		$u = get_userdata($user_id);
		$email = $u ? $u->user_email : '';
		$login = $u ? $u->user_login : '';
		$cpt_limit = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE p.post_type IN ('wc_cs_credits', 'credits', 'fpc_credits')
			   AND p.post_status = 'publish'
			   AND pm.meta_key IN (
			       'approved_credits', '_approved_credits', 'wc_cs_approved_credits',
			       'credit_limit', '_credit_limit', 'wc_cs_credit_limit', '_wc_cs_credit_limit',
			       'fpc_credit_limit', '_fpc_credit_limit'
			   )
			   AND CAST(pm.meta_value AS DECIMAL(10,2)) > 0
			   AND (
			       p.post_author = %d
			       OR p.post_title = %s
			       OR p.post_title = %s
			       OR p.ID IN (
			           SELECT post_id FROM {$wpdb->postmeta}
			           WHERE meta_key IN (
				           '_user_id', 'user_id', 'wc_cs_user_id', '_wc_cs_user_id',
				           'customer_id', '_customer_id', 'customer_user', '_customer_user',
				           'email', '_email', 'user_email', '_user_email', 'wc_cs_user_email', '_wc_cs_user_email'
			           ) AND (meta_value = %s OR meta_value = %s OR meta_value = %s)
			       )
			   )
			 ORDER BY CAST(pm.meta_value AS DECIMAL(10,2)) DESC LIMIT 1",
			$user_id,
			$login,
			$email,
			(string) $user_id,
			$email,
			$login
		));
		if ($cpt_limit > $discovered_limit) {
			$discovered_limit = $cpt_limit;
		}

		// Initialize authoritative usermeta so future lookups are immediate and consistent
		if ($discovered_limit > 0) {
			update_user_meta($user_id, '_credit_limit', $discovered_limit);
			self::sync_user_credit_limit($user_id, $discovered_limit);
		}

		return max(0.0, $discovered_limit);
	}

	/**
	 * Get the synchronized credit balance (amount owed) for a user across all meta sources
	 *
	 * @param int $user_id
	 * @return float
	 */
	public static function get_user_credit_balance($user_id)
	{
		$user_id = (int) $user_id;
		if (! $user_id) {
			return 0.0;
		}

		// 1. If user is a brand new applicant with an unapproved pending application and NO active account, they owe 0.0
		if (class_exists('CWD_V2_Trade_Applications')) {
			global $wpdb;
			$apps_table = CWD_V2_Trade_Applications::get_table_name();
			if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $apps_table)) === $apps_table) {
				$u             = get_userdata($user_id);
				$is_active_acc = (float) get_user_meta($user_id, '_credit_limit', true) > 0 || ($u && in_array('credit_account', (array) $u->roles, true));
				if (! $is_active_acc) {
					$has_pending = (int) $wpdb->get_var($wpdb->prepare(
						"SELECT COUNT(*) FROM {$apps_table} WHERE (user_id = %d OR applicant_email = %s) AND status = 'pending'",
						$user_id,
						$u ? $u->user_email : ''
					));
					$has_approved = (int) $wpdb->get_var($wpdb->prepare(
						"SELECT COUNT(*) FROM {$apps_table} WHERE (user_id = %d OR applicant_email = %s) AND status = 'approved' AND reviewed_by > 0",
						$user_id,
						$u ? $u->user_email : ''
					));
					if ($has_pending > 0 && $has_approved === 0) {
						return 0.0;
					}
				}
			}
		}

		if (metadata_exists('user', $user_id, '_credit_balance')) {
			return max(0.0, (float) get_user_meta($user_id, '_credit_balance', true));
		}

		$balance = 0.0;
		// Outstanding / owed keys ONLY (never credit_balance or _user_credit_balance which mean available credit!)
		$keys = array(
			'total_outstanding_amount', '_total_outstanding_amount',
			'wc_cs_total_outstanding_amount', '_wc_cs_total_outstanding_amount',
			'total_outstanding', '_total_outstanding',
			'outstanding_credits', 'wc_cs_outstanding_credits',
			'used_credits', '_used_credits', '_fp_used_credit'
		);
		foreach ($keys as $k) {
			$val = (float) get_user_meta($user_id, $k, true);
			if ($val > 0) {
				$balance = $val;
				update_user_meta($user_id, '_credit_balance', $balance);
				break;
			}
		}

		// Fallback to unpaid invoices in cwd_v2_invoices table if balance is 0
		if ($balance <= 0 && class_exists('CWD_V2_Invoices')) {
			global $wpdb;
			$invoices_table = CWD_V2_Invoices::table_name();
			if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $invoices_table)) === $invoices_table) {
				$unpaid_invoices_total = (float) $wpdb->get_var($wpdb->prepare(
					"SELECT SUM(GREATEST(0, amount_total - amount_paid)) FROM {$invoices_table}
					 WHERE user_id = %d AND status NOT IN ('paid', 'void', 'written_off', 'marked_off')",
					$user_id
				));
				if ($unpaid_invoices_total > 0) {
					$balance = $unpaid_invoices_total;
					update_user_meta($user_id, '_credit_balance', $balance);
				}
			}
		}

		// Fallback to external Credits CPT postmeta if still 0
		if ($balance <= 0) {
			global $wpdb;
			$u = get_userdata($user_id);
			$email = $u ? $u->user_email : '';
			$login = $u ? $u->user_login : '';
			$cpt_balance = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE p.post_type IN ('wc_cs_credits', 'credits', 'fpc_credits')
				   AND pm.meta_key IN (
				       'total_outstanding_amount', '_total_outstanding_amount',
				       'wc_cs_total_outstanding_amount', '_wc_cs_total_outstanding_amount',
				       'total_outstanding', '_total_outstanding',
				       'wc_cs_total_outstanding', '_wc_cs_total_outstanding',
				       'outstanding_credits', 'wc_cs_outstanding_credits',
				       'used_credits', '_used_credits'
				   )
				   AND CAST(pm.meta_value AS DECIMAL(10,2)) > 0
				   AND (
				       p.post_author = %d
				       OR p.post_title = %s
				       OR p.post_title = %s
				       OR p.ID IN (
				           SELECT post_id FROM {$wpdb->postmeta}
				           WHERE meta_key IN (
				               '_user_id', 'user_id', 'wc_cs_user_id', '_wc_cs_user_id',
				               'customer_id', '_customer_id', 'customer_user', '_customer_user',
				               'fpc_user_id', 'user_email', '_user_email', 'wc_cs_user_email',
				               '_wc_cs_user_email', 'email', '_email'
				           ) AND (meta_value = %s OR meta_value = %s OR meta_value = %s)
				       )
				   )
				 ORDER BY CAST(pm.meta_value AS DECIMAL(10,2)) DESC LIMIT 1",
				$user_id,
				$login,
				$email,
				(string) $user_id,
				$email,
				$login
			));
			if ($cpt_balance > 0) {
				$balance = $cpt_balance;
				update_user_meta($user_id, '_credit_balance', $balance);
			}
		}

		return max(0.0, $balance);
	}

	/**
	 * Sync credit limit across all relevant meta keys and CPT post
	 *
	 * @param int $user_id
	 * @param float $limit
	 */
	public static function sync_user_credit_limit($user_id, $limit)
	{
		$user_id = (int) $user_id;
		$limit   = max(0.0, round((float) $limit, 2));
		if (! $user_id) {
			return;
		}

		// 1. Authoritative user meta
		update_user_meta($user_id, '_credit_limit', $limit);

		// 2. All legacy & plugin-specific user meta keys
		$keys = array(
			'_fp_credit_limit', 'fp_credit_limit', '_user_credit_limit', 'credit_limit',
			'_wc_cs_credit_limit', 'wc_cs_credit_limit',
			'_approved_credits', 'approved_credits',
			'_approved_credit', 'approved_credit',
			'_wc_cs_approved_credits', 'wc_cs_approved_credits',
			'_fpc_credit_limit', 'fpc_credit_limit',
			'_credits_limit', 'credits_limit',
		);
		foreach ($keys as $k) {
			update_user_meta($user_id, $k, $limit);
		}

		// 3. Available credit calculations
		$current_balance = (float) get_user_meta($user_id, '_credit_balance', true);
		$available = max(0.0, $limit - $current_balance);
		$avail_keys = array(
			'_available_credits', 'available_credits',
			'_wc_cs_available_credits', 'wc_cs_available_credits',
			'fpc_available_credits', 'available_credit'
		);
		foreach ($avail_keys as $ak) {
			update_user_meta($user_id, $ak, $available);
		}

		// 4. Synchronize trade application rows in wp_cwd_v2_trade_applications
		if (class_exists('CWD_V2_Trade_Applications')) {
			global $wpdb;
			$apps_table = CWD_V2_Trade_Applications::get_table_name();
			if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $apps_table)) === $apps_table) {
				$u = get_userdata($user_id);
				$email = $u ? $u->user_email : '';
				$wpdb->query($wpdb->prepare(
					"UPDATE {$apps_table} 
					 SET approved_limit = %f, user_id = %d, updated_at = %s 
					 WHERE (user_id = %d OR (applicant_email = %s AND applicant_email != '')) AND status = 'approved'",
					$limit,
					$user_id,
					current_time('mysql'),
					$user_id,
					$email
				));
			}
		}

		// 5. Synchronize credit post in Credits > Credits with explicit limit value
		if (class_exists('CWD_V2_Credits_Bridge') && method_exists('CWD_V2_Credits_Bridge', 'sync_user_to_credits_post')) {
			CWD_V2_Credits_Bridge::sync_user_to_credits_post($user_id, $limit);
		}
	}

	/**
	 * Sync credit balance across all relevant meta keys and external CPT post
	 *
	 * @param int $user_id
	 * @param float $balance
	 */
	public static function sync_user_credit_balance($user_id, $balance)
	{
		$user_id = (int) $user_id;
		$balance = max(0.0, round((float) $balance, 2));
		if (! $user_id) {
			return;
		}

		update_user_meta($user_id, '_credit_balance', $balance);
		// Outstanding / owed keys ONLY (never credit_balance or _user_credit_balance which mean available credit in third-party plugins!)
		$keys = array(
			'_fp_used_credit', 'used_credits', '_used_credits', '_credit_used',
			'total_outstanding', '_total_outstanding', 'wc_cs_total_outstanding',
			'_wc_cs_total_outstanding', 'outstanding_credits', 'wc_cs_outstanding_credits',
			'total_outstanding_amount', '_total_outstanding_amount',
			'wc_cs_total_outstanding_amount', '_wc_cs_total_outstanding_amount'
		);
		foreach ($keys as $k) {
			update_user_meta($user_id, $k, $balance);
		}

		$limit = self::get_user_credit_limit($user_id);
		$avail = max(0.0, round($limit - $balance, 2));
		$avail_keys = array(
			'_available_credits', 'available_credits',
			'_wc_cs_available_credits', 'wc_cs_available_credits',
			'fpc_available_credits', 'available_credit',
			'credit_balance', '_user_credit_balance'
		);
		foreach ($avail_keys as $ak) {
			update_user_meta($user_id, $ak, $avail);
		}

		// Update external CPT posts in 'credits' / 'wc_cs_credits' / 'fpc_credits'
		global $wpdb;
		$u = get_userdata($user_id);
		$email = $u ? $u->user_email : '';
		$login = $u ? $u->user_login : '';
		$post_ids = $wpdb->get_col($wpdb->prepare(
			"SELECT DISTINCT p.ID FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
			 WHERE p.post_type IN ('credits', 'wc_cs_credits', 'fpc_credits')
			   AND (p.post_author = %d OR (pm.meta_key IN ('_user_id', 'user_id', 'wc_cs_user_id', '_wc_cs_user_id', 'fpc_user_id', 'customer_id', 'email', 'user_email', 'wc_cs_user_email') AND (pm.meta_value = %s OR pm.meta_value = %s OR pm.meta_value = %s)))",
			$user_id,
			(string) $user_id,
			$email,
			$login
		));

		if (! empty($post_ids)) {
			foreach ($post_ids as $pid) {
				update_post_meta((int) $pid, 'total_outstanding_amount', $balance);
				update_post_meta((int) $pid, '_total_outstanding_amount', $balance);
				update_post_meta((int) $pid, 'wc_cs_total_outstanding_amount', $balance);
				update_post_meta((int) $pid, '_wc_cs_total_outstanding_amount', $balance);
				update_post_meta((int) $pid, 'total_outstanding', $balance);
				update_post_meta((int) $pid, '_total_outstanding', $balance);
				update_post_meta((int) $pid, 'wc_cs_total_outstanding', $balance);
				update_post_meta((int) $pid, '_wc_cs_total_outstanding', $balance);
				update_post_meta((int) $pid, 'outstanding_credits', $balance);
				update_post_meta((int) $pid, 'wc_cs_outstanding_credits', $balance);
				update_post_meta((int) $pid, 'used_credits', $balance);
				update_post_meta((int) $pid, '_used_credits', $balance);
				update_post_meta((int) $pid, 'available_credits', $avail);
				update_post_meta((int) $pid, '_available_credits', $avail);
				update_post_meta((int) $pid, 'wc_cs_available_credits', $avail);
				update_post_meta((int) $pid, '_wc_cs_available_credits', $avail);
				update_post_meta((int) $pid, 'fpc_available_credits', $avail);
				clean_post_cache((int) $pid);
			}
		}
	}

	/**
	 * Recalculate live outstanding credit balance from unpaid invoices & orders, and sync
	 *
	 * @param int $user_id
	 * @return float
	 */
	public static function recalculate_and_sync_user_credit_balance($user_id)
	{
		$user_id = (int) $user_id;
		if (! $user_id) {
			return 0.0;
		}

		global $wpdb;
		$total_unpaid = 0.0;

		// 1. Calculate unpaid invoices from invoices table
		if (class_exists('CWD_V2_Invoices')) {
			$invoices_table = CWD_V2_Invoices::table_name();
			if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $invoices_table)) === $invoices_table) {
				$inv_total = (float) $wpdb->get_var($wpdb->prepare(
					"SELECT SUM(GREATEST(0, amount_total - amount_paid)) FROM {$invoices_table}
					 WHERE user_id = %d AND status NOT IN ('paid', 'void', 'written_off', 'marked_off')",
					$user_id
				));
				$total_unpaid += $inv_total;
			}
		}

		// 2. Add unsettled WooCommerce credit orders not yet invoiced
		$credit_orders = wc_get_orders(array(
			'customer_id' => $user_id,
			'limit'       => 100,
			'status'      => array('processing', 'completed', 'on-hold', 'pending'),
		));
		$has_credit_order = false;
		foreach ($credit_orders as $ord) {
			$pm = strtolower((string) $ord->get_payment_method());
			$is_credit_ord = in_array($pm, array('cwd_v2_credit_account', 'credits', 'wc_cs', 'wc_cs_credits', 'fpc_credits', 'trade_credit'), true)
				|| ('yes' === $ord->get_meta('_paid_with_credit'))
				|| ((float) $ord->get_meta('_credit_charged_amount') > 0);
			if ($is_credit_ord) {
				$has_credit_order = true;
				if ($ord->get_meta('_credit_order_settled') !== 'yes' && ! $ord->get_meta('_invoiced')) {
					$total_unpaid += (float) $ord->get_total();
				}
			}
		}

		// 3. If user has no orders and no invoices, balance is strictly 0.0
		if ($total_unpaid <= 0 && ! $has_credit_order) {
			$total_unpaid = 0.0;
		}

		self::sync_user_credit_balance($user_id, $total_unpaid);
		return $total_unpaid;
	}

	public static function apply_credit_order_charge($order_id)
	{
		$order = wc_get_order($order_id);
		if (! $order) {
			return;
		}

		// Prevent duplicate deduction
		if ($order->get_meta('_cwd_v2_credit_charge_processed')) {
			return;
		}

		$method = strtolower((string) $order->get_payment_method());
		$is_credit_method = in_array($method, array('cwd_v2_credit_account', 'credits', 'wc_cs', 'wc_cs_credits', 'fpc_credits', 'wc_credit_gateway', 'credits_gateway', 'woocommerce_credits', 'trade_credit'), true)
			|| (strpos($method, 'credit') !== false && strpos($method, 'card') === false && strpos($method, 'stripe') === false);

		$paid_with_credit = $order->get_meta('_paid_with_credit');
		$credits_used_meta = (float) ($order->get_meta('_wc_cs_credits_used')
			?: ($order->get_meta('wc_cs_credits_used')
			?: ($order->get_meta('_wc_cs_credit_amount')
			?: ($order->get_meta('wc_cs_credit_amount')
			?: ($order->get_meta('_credits_used')
			?: ($order->get_meta('credits_used')
			?: ($order->get_meta('_fpc_credit_amount')
			?: $order->get_meta('fpc_credits_used'))))))));

		$has_credit_fee = false;
		$fee_credit_amount = 0.0;
		foreach ($order->get_fees() as $fee) {
			if (preg_match('/credit/i', $fee->get_name())) {
				$has_credit_fee = true;
				$fee_credit_amount += abs((float) $fee->get_total());
			}
		}

		$is_credit_order = $is_credit_method || ('yes' === $paid_with_credit) || ($credits_used_meta > 0) || $has_credit_fee;
		if (! $is_credit_order) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		if (! $user_id) {
			return;
		}

		$order_total = round((float) $order->get_total(), 2);
		$amount = $order_total;
		if (! $is_credit_method && $credits_used_meta > 0) {
			$amount = round($credits_used_meta, 2);
		} elseif (! $is_credit_method && $fee_credit_amount > 0) {
			$amount = round($fee_credit_amount, 2);
		}

		if ($amount <= 0) {
			return;
		}

		$current_balance = self::get_user_credit_balance($user_id);
		$new_balance     = round($current_balance + $amount, 2);

		// Flag order as processed immediately
		$order->update_meta_data('_cwd_v2_credit_charge_processed', 'yes');
		$order->update_meta_data('_paid_with_credit', 'yes');
		$order->update_meta_data('_credit_charged_amount', $amount);
		$order->update_meta_data('_credit_balance_prior_order', $current_balance);
		$order->update_meta_data('_credit_balance_after_order', $new_balance);
		$order->save();

		// Update and sync balance across all meta keys, tables, and external CPT
		self::sync_user_credit_balance($user_id, $new_balance);

		// Record in transaction ledger
		if (class_exists('CWD_V2_Account_Ledger')) {
			CWD_V2_Account_Ledger::record(
				$user_id,
				CWD_V2_Account_Ledger::TYPE_CHARGE,
				$amount,
				'order',
				$order_id,
				sprintf(__('Order #%d placed on credit account', 'custom-woo-dashboard'), $order_id)
			);
		}

		// Ensure unpaid invoice is immediately generated in CWD_V2_Invoices
		if (class_exists('CWD_V2_Invoices')) {
			CWD_V2_Invoices::generate_invoice_for_order($order_id);
		}

		do_action('cwd_v2_credit_charged', $user_id, $amount, $new_balance, $order_id);
		do_action('wc_cs_credit_debited', $user_id, $amount, $new_balance, $order_id);
	}

	public static function reverse_credit_order_charge($order_id)
	{
		$order = wc_get_order($order_id);
		if (! $order) {
			return;
		}

		$method = strtolower((string) $order->get_payment_method());
		$is_credit_method = in_array($method, array('cwd_v2_credit_account', 'credits', 'wc_cs', 'wc_cs_credits', 'fpc_credits', 'wc_credit_gateway', 'credits_gateway', 'woocommerce_credits', 'trade_credit'), true)
			|| (strpos($method, 'credit') !== false && strpos($method, 'card') === false && strpos($method, 'stripe') === false);

		$paid_with_credit = $order->get_meta('_paid_with_credit');
		$is_credit_order  = $is_credit_method || ('yes' === $paid_with_credit) || $order->get_meta('_credit_charged_amount');

		if (! $is_credit_order || ! $order->get_meta('_cwd_v2_credit_charge_processed') || $order->get_meta('_cwd_v2_credit_charge_reversed')) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		$charged = (float) $order->get_meta('_credit_charged_amount');
		$amount  = $charged > 0 ? $charged : round((float) $order->get_total(), 2);
		if (! $user_id || $amount <= 0) {
			return;
		}

		$current_balance = self::get_user_credit_balance($user_id);
		$new_balance     = max(0.0, round($current_balance - $amount, 2));
		self::sync_user_credit_balance($user_id, $new_balance);

		if (class_exists('CWD_V2_Account_Ledger')) {
			CWD_V2_Account_Ledger::record(
				$user_id,
				CWD_V2_Account_Ledger::TYPE_REFUND,
				$amount,
				'order',
				$order_id,
				sprintf(__('Credit charge reversed for order #%d', 'custom-woo-dashboard'), $order_id)
			);
		}

		$order->update_meta_data('_cwd_v2_credit_charge_reversed', 'yes');
		$order->save();
	}

	/**
	 * Reconcile refunds for both credit orders and invoice-payment orders.
	 * Invoice payments restore the balance and reopen the invoice; credit-order
	 * refunds reduce the balance created by the original purchase.
	 *
	 * @param int $order_id
	 * @param int $refund_id
	 */
	public static function handle_credit_order_refund($order_id, $refund_id)
	{
		$order = wc_get_order($order_id);
		$refund = wc_get_order($refund_id);
		if (! $order || ! $refund || $refund->get_meta('_cwd_v2_credit_refund_processed')) {
			return;
		}

		$invoice_id = 0;
		$product_id = (int) get_option('cwd_v2_credit_payment_product_id');
		foreach ($order->get_items() as $item) {
			if ($product_id && $item->get_product_id() === $product_id && $item->get_meta('cwd_v2_invoice_id')) {
				$invoice_id = absint($item->get_meta('cwd_v2_invoice_id'));
				break;
			}
		}

		$method = $order->get_payment_method();
		$is_credit_order = in_array($method, array('cwd_v2_credit_account', 'credits'), true);

		if (! $invoice_id && ! $is_credit_order) {
			return;
		}

		$refund_amount = method_exists($refund, 'get_amount') ? abs((float) $refund->get_amount()) : abs((float) $refund->get_total());
		$refund_amount = min($refund_amount, abs((float) $order->get_total()));
		if ($refund_amount <= 0) {
			return;
		}

		$user_id = $order->get_user_id();
		if (! $user_id) {
			return;
		}

		$current_balance = self::get_user_credit_balance($user_id);

		if ($invoice_id) {
			if (! CWD_V2_Invoices::reverse_invoice_payment($invoice_id, $user_id, $refund_amount)) {
				return;
			}
			$new_balance = $current_balance + $refund_amount;
			$ledger_type = CWD_V2_Account_Ledger::TYPE_REFUND;
			$reference_type = 'invoice';
			$reference_id = $invoice_id;
		} else {
			$new_balance = max(0.0, $current_balance - $refund_amount);
			$ledger_type = CWD_V2_Account_Ledger::TYPE_REFUND;
			$reference_type = 'order';
			$reference_id = $order_id;
		}

		self::sync_user_credit_balance($user_id, $new_balance);

		CWD_V2_Account_Ledger::record(
			$user_id,
			$ledger_type,
			$refund_amount,
			$reference_type,
			$reference_id,
			sprintf(__('Refund for order #%d', 'custom-woo-dashboard'), $order_id)
		);

		$refund->update_meta_data('_cwd_v2_credit_refund_processed', 'yes');
		$refund->save();
	}
}

<?php

/**
 * REST API Integration for Odoo Credit Sync
 */

if (! defined('ABSPATH')) {
	exit;
}

class CWD_V2_REST_API
{

	public static function init()
	{
		// Register meta keys for user REST API visibility
		add_action('init', array(__CLASS__, 'register_user_meta_fields'));

		// Intercept WooCommerce REST API Customer inserts/updates (from Odoo sync)
		add_filter('woocommerce_rest_pre_insert_customer_object', array(__CLASS__, 'handle_rest_customer_save'), 10, 3);

		// Expose credit info in WooCommerce REST API Customer response
		add_filter('woocommerce_rest_prepare_customer', array(__CLASS__, 'prepare_rest_customer_response'), 10, 3);

		// Register a dedicated direct sync route for Odoo
		add_action('rest_api_init', array(__CLASS__, 'register_credit_sync_routes'));
	}

	/**
	 * Register meta keys so WordPress REST API recognizes them
	 */
	public static function register_user_meta_fields()
	{
		$meta_keys = array(
			'_credit_limit' => array(
				'type'        => 'number',
				'description' => 'Customer credit limit',
			),
			'_credit_balance' => array(
				'type'        => 'number',
				'description' => 'Current outstanding credit balance',
			),
			'_credit_due_date' => array(
				'type'        => 'string',
				'description' => 'Credit balance due date',
			),
			'ews_account_number' => array(
				'type'        => 'string',
				'description' => 'EWS trade account number',
			),
		);

		foreach ($meta_keys as $key => $args) {
			register_meta(
				'user',
				$key,
				array(
					'type'         => $args['type'],
					'description'  => $args['description'],
					'single'       => true,
					'show_in_rest' => true,
					'auth_callback' => array(__CLASS__, 'rest_meta_auth_callback'),
				)
			);
		}
	}

	/**
	 * Authorization callback for credit meta in REST API
	 */
	public static function rest_meta_auth_callback($request = null)
	{
		if (current_user_can('manage_woocommerce') || current_user_can('manage_options')) {
			return true;
		}

		if ($request instanceof WP_REST_Request) {
			$auth_header = $request->get_header('X-Odoo-Secret') 
				?: $request->get_header('X-CWD-SECRET-KEY') 
				?: $request->get_header('X-ODOO-SECRET') 
				?: $request->get_param('secret_key');

			$secret_key = defined('CWD_ODOO_SECRET_KEY') ? CWD_ODOO_SECRET_KEY : get_option('cwd_odoo_secret_key', '');

			if (! empty($secret_key) && ! empty($auth_header) && hash_equals((string) $secret_key, (string) $auth_header)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Intercept WooCommerce REST API customer updates to capture credit metadata from Odoo
	 *
	 * @param WC_Customer $customer
	 * @param WP_REST_Request $request
	 * @param bool $creating
	 * @return WC_Customer
	 */
	public static function handle_rest_customer_save($customer, $request, $creating)
	{
		// 1. Process meta_data array from payload
		$meta_data = $request->get_param('meta_data');
		if (is_array($meta_data)) {
			foreach ($meta_data as $meta_item) {
				if (! isset($meta_item['key'], $meta_item['value'])) {
					continue;
				}
				$key   = sanitize_key($meta_item['key']);
				$value = $meta_item['value'];

				if (in_array($key, array('_credit_limit', 'credit_limit'), true)) {
					$limit = round((float) wc_format_decimal($value), 2);
					$customer->update_meta_data('_credit_limit', max(0, $limit));
					if (class_exists('CWD_V2_Credit_Logic') && $customer->get_id()) {
						CWD_V2_Credit_Logic::sync_user_credit_limit($customer->get_id(), max(0, $limit));
					}
				} elseif (in_array($key, array('_credit_balance', 'credit_balance'), true)) {
					$balance = round((float) wc_format_decimal($value), 2);
					$customer->update_meta_data('_credit_balance', max(0, $balance));
					if (class_exists('CWD_V2_Credit_Logic') && $customer->get_id()) {
						CWD_V2_Credit_Logic::sync_user_credit_balance($customer->get_id(), max(0, $balance));
					}
				} elseif (in_array($key, array('_credit_due_date', 'credit_due_date'), true)) {
					$customer->update_meta_data('_credit_due_date', sanitize_text_field($value));
				} elseif (in_array($key, array('ews_account_number', '_ews_account_number'), true)) {
					$customer->update_meta_data('ews_account_number', sanitize_text_field($value));
				}
			}
		}

		// 2. Process top-level params if provided directly
		if (null !== $request->get_param('credit_limit')) {
			$limit = round((float) wc_format_decimal($request->get_param('credit_limit')), 2);
			$customer->update_meta_data('_credit_limit', max(0, $limit));
			if (class_exists('CWD_V2_Credit_Logic') && $customer->get_id()) {
				CWD_V2_Credit_Logic::sync_user_credit_limit($customer->get_id(), max(0, $limit));
			}
		}
		if (null !== $request->get_param('credit_balance')) {
			$balance = round((float) wc_format_decimal($request->get_param('credit_balance')), 2);
			$customer->update_meta_data('_credit_balance', max(0, $balance));
			if (class_exists('CWD_V2_Credit_Logic') && $customer->get_id()) {
				CWD_V2_Credit_Logic::sync_user_credit_balance($customer->get_id(), max(0, $balance));
			}
		}
		if (null !== $request->get_param('ews_account_number')) {
			$customer->update_meta_data('ews_account_number', sanitize_text_field($request->get_param('ews_account_number')));
		}

		return $customer;
	}

	/**
	 * Append formatted credit fields to the WooCommerce Customer REST response
	 *
	 * @param WP_REST_Response $response
	 * @param WC_Customer $customer
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function prepare_rest_customer_response($response, $customer, $request)
	{
		$user_id = $customer->get_id();
		if (! $user_id) {
			return $response;
		}

		$credit_limit     = class_exists('CWD_V2_Credit_Logic') ? CWD_V2_Credit_Logic::get_user_credit_limit($user_id) : (float) get_user_meta($user_id, '_credit_limit', true);
		$credit_balance   = class_exists('CWD_V2_Credit_Logic') ? CWD_V2_Credit_Logic::get_user_credit_balance($user_id) : (float) get_user_meta($user_id, '_credit_balance', true);
		$available_credit = max(0, $credit_limit - $credit_balance);
		$due_date         = (string) get_user_meta($user_id, '_credit_due_date', true);
		$account_number   = (string) get_user_meta($user_id, 'ews_account_number', true);

		$data = $response->get_data();
		$data['credit_account'] = array(
			'is_credit_customer' => in_array('credit_account', (array) $customer->get_role(), true) || in_array('credit_account', (array) get_userdata($user_id)->roles, true) || $credit_limit > 0,
			'credit_limit'       => $credit_limit,
			'credit_balance'     => $credit_balance,
			'available_credit'   => $available_credit,
			'credit_due_date'    => $due_date,
			'ews_account_number' => $account_number,
		);
		$response->set_data($data);

		return $response;
	}

	/**
	 * Dedicated direct sync endpoint: POST /wp-json/cwd/v2/sync-credit
	 */
	public static function register_credit_sync_routes()
	{
		register_rest_route(
			'cwd/v2',
			'/sync-credit',
			array(
				'methods'             => 'POST',
				'callback'            => array(__CLASS__, 'handle_direct_credit_sync'),
				'permission_callback' => array(__CLASS__, 'rest_meta_auth_callback'),
				'args'                => array(
					'customer_id' => array(
						'type'        => 'integer',
						'required'    => false,
						'description' => 'WooCommerce customer ID',
					),
					'email' => array(
						'type'        => 'string',
						'required'    => false,
						'description' => 'Customer email address',
					),
					'credit_limit' => array(
						'type'        => 'number',
						'required'    => false,
						'description' => 'Credit limit in pounds',
					),
					'credit_balance' => array(
						'type'        => 'number',
						'required'    => false,
						'description' => 'Current outstanding balance in pounds',
					),
					'ews_account_number' => array(
						'type'        => 'string',
						'required'    => false,
						'description' => 'EWS trade account number',
					),
					'credit_due_date' => array(
						'type'        => 'string',
						'required'    => false,
						'description' => 'Payment due date',
					),
					'enable_credit' => array(
						'type'        => 'boolean',
						'required'    => false,
						'description' => 'Assign credit_account role',
					),
				),
			)
		);

		register_rest_route(
			'cwd/v2',
			'/sync-invoice',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_direct_invoice_sync' ),
				'permission_callback' => array( __CLASS__, 'rest_meta_auth_callback' ),
				'args'                => array(
					'customer_id'     => array( 'type' => 'integer', 'required' => false ),
					'email'           => array( 'type' => 'string',  'required' => false ),
					'odoo_invoice_id' => array( 'type' => 'string',  'required' => true ),
					'invoice_number'  => array( 'type' => 'string',  'required' => false ),
					'invoice_date'    => array( 'type' => 'string',  'required' => false ),
					'due_date'        => array( 'type' => 'string',  'required' => false ),
					'amount_total'    => array( 'type' => 'number',  'required' => false ),
					'amount_paid'     => array( 'type' => 'number',  'required' => false ),
					'status'          => array( 'type' => 'string',  'required' => false ),
					'document_url'    => array( 'type' => 'string',  'required' => false ),
				),
			)
		);
	}

	/**
	 * Process direct credit sync request from Odoo
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function handle_direct_credit_sync($request)
	{
		$customer_id = (int) $request->get_param('customer_id');
		$email       = sanitize_email($request->get_param('email'));

		$user = null;
		if ($customer_id > 0) {
			$user = get_userdata($customer_id);
		}
		if (! $user && ! empty($email)) {
			$user = get_user_by('email', $email);
		}

		if (! $user) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __('Customer not found.', 'custom-woo-dashboard'),
				),
				404
			);
		}

		$user_id = $user->ID;

		if (null !== $request->get_param('credit_limit')) {
			$limit = round((float) wc_format_decimal($request->get_param('credit_limit')), 2);
			update_user_meta($user_id, '_credit_limit', max(0, $limit));
			if (class_exists('CWD_V2_Credit_Logic')) {
				CWD_V2_Credit_Logic::sync_user_credit_limit($user_id, max(0, $limit));
			}
		}

		if (null !== $request->get_param('credit_balance')) {
			$balance = round((float) wc_format_decimal($request->get_param('credit_balance')), 2);
			update_user_meta($user_id, '_credit_balance', max(0, $balance));
			if (class_exists('CWD_V2_Credit_Logic')) {
				CWD_V2_Credit_Logic::sync_user_credit_balance($user_id, max(0, $balance));
			}
		}

		if (null !== $request->get_param('credit_due_date')) {
			update_user_meta($user_id, '_credit_due_date', sanitize_text_field($request->get_param('credit_due_date')));
		}

		if (null !== $request->get_param('ews_account_number')) {
			update_user_meta($user_id, 'ews_account_number', sanitize_text_field($request->get_param('ews_account_number')));
		}

		if (true === $request->get_param('enable_credit') || (isset($limit) && $limit > 0)) {
			if (! in_array('credit_account', (array) $user->roles, true)) {
				$user->add_role('credit_account');
			}
		}

		if (class_exists('CWD_V2_Credits_Bridge')) {
			CWD_V2_Credits_Bridge::sync_user_to_credits_post($user_id);
		}

		$final_limit     = (float) get_user_meta($user_id, '_credit_limit', true);
		$final_balance   = (float) get_user_meta($user_id, '_credit_balance', true);
		$available_credit = max(0, $final_limit - $final_balance);

		return new WP_REST_Response(
			array(
				'success'          => true,
				'customer_id'      => $user_id,
				'email'            => $user->user_email,
				'credit_limit'     => $final_limit,
				'credit_balance'   => $final_balance,
				'available_credit' => $available_credit,
				'ews_account_number' => (string) get_user_meta($user_id, 'ews_account_number', true),
			),
			200
		);
	}

	/**
	 * Process direct invoice sync request from Odoo.
	 * POST /wp-json/cwd/v2/sync-invoice
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function handle_direct_invoice_sync( $request )
	{
		$customer_id = (int) $request->get_param( 'customer_id' );
		$email       = sanitize_email( (string) $request->get_param( 'email' ) );

		$user = null;
		if ( $customer_id > 0 ) {
			$user = get_userdata( $customer_id );
		}
		if ( ! $user && ! empty( $email ) ) {
			$user = get_user_by( 'email', $email );
		}
		if ( ! $user && $request->get_param( 'order_id' ) ) {
			$order = wc_get_order( absint( $request->get_param( 'order_id' ) ) );
			if ( $order && $order->get_user_id() ) {
				$user = get_userdata( $order->get_user_id() );
			}
		}
		if ( ! $user ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Customer not found.', 'custom-woo-dashboard' ) ),
				404
			);
		}

		$row = array(
			'odoo_invoice_id' => $request->get_param( 'odoo_invoice_id' ),
			'order_id'        => $request->get_param( 'order_id' ),
			'invoice_number'  => $request->get_param( 'invoice_number' ),
			'invoice_date'    => $request->get_param( 'invoice_date' ),
			'due_date'        => $request->get_param( 'due_date' ),
			'amount_total'    => $request->get_param( 'amount_total' ),
			'amount_paid'     => $request->get_param( 'amount_paid' ),
			'status'          => $request->get_param( 'status' ),
			'document_url'    => $request->get_param( 'document_url' ),
		);

		$ok = CWD_V2_Invoices::upsert_odoo_invoice( $user->ID, $row );

		$live_balance = 0.0;
		if ( $ok && class_exists( 'CWD_V2_Credit_Logic' ) ) {
			$live_balance = CWD_V2_Credit_Logic::recalculate_and_sync_user_credit_balance( $user->ID );
		}

		return new WP_REST_Response(
			array(
				'success'        => $ok,
				'customer_id'    => $user->ID,
				'email'          => $user->user_email,
				'credit_balance' => $live_balance,
			),
			$ok ? 200 : 500
		);
	}
}
